/* Just test that the file can be compiled successfully. */

#include "messages2.pb.h"

int main()
{
    return xmit_size;
}

